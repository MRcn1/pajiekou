import instance from '../index'
/**
 * get方法
 * @returns {Promise<AxiosResponse<any>>}
 */
export function getInnerPlugsVersion(url) {
    return instance.get(url + '/public/getInnerPlugsVersion')
}

/**
 * post方法
 * @returns {Promise<AxiosResponse<any>>}
 */
export function postDemo() {
    return instance.post('/public/getInnerPlugsVersion')
}

/**
 * post方法
 * @returns {Promise<AxiosResponse<any>>}
 */
export function eastmoney() {
    return instance.get('https://datainterface3.eastmoney.com/EM_DataCenter_V3/api/LHBJGTJ/GetHBJGTJ?sortfield=PBuy&sortdirec=1&pageSize=5&pageNum=1&tkn=eastmoney&code=&mkt=&dateNum=&cfg=lhbjgtj&startDateTime=2021-07-26&endDateTime=2021-07-26')
}