import {
    eastmoney
} from '../assets/js/request/api/user'
chrome.runtime.onConnect.addListener(function (port) {
    port.onMessage.addListener(function (msg) {
        console.log(msg)
        switch (msg.code) {
            case 'save_goods_info':
                eastmoney(msg.params).then(res => {
                    if (res.data.Status == 2) {
                        port.postMessage({
                            code: 'return_save_goods_info',
                            res: res.data.data
                        })
                    }
                })
                break
            default:
                break
        }
    })
})