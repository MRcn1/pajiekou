import {
    eastmoney
} from '../assets/js/request/api/user'
chrome.runtime.onConnect.addListener(function (port) {
    port.onMessage.addListener(function (msg) {
        console.log(msg)
        switch (msg.code) {
        case 'save_goods_info':
            eastmoney(msg.params).then(res=>{
                console.log(res);
            })
            break
        default:
            break
        }
    })
})
