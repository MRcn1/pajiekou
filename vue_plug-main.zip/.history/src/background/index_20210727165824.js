import {
    eastmoney
} from '../assets/js/request/api/user'
chrome.runtime.onConnect.addListener(function (port) {
    port.onMessage.addListener(function (msg) {
        console.log(msg)
        switch (msg.code) {
        case 'save_goods_info':
            eastmoney()
            break
        default:
            break
        }
    })
})
