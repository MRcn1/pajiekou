<template>
    <div class="standalone">
        <button @click="longzhuashou">龙抓手</button>
    </div>
</template>
<script>
    var port = chrome.runtime.connect({
        name: 'LOGIN_DATA'
    })
    export default {
        data() {
            return {
                data:'',
                data2:[],
            }
        },
        mounted() {
            port.onMessage.addListener(msg => {
                console.log('return', msg);
                if (msg.code === 'return_save_goods_info') {
                    let data = msg.res.data.Data[0].Data
                    data = data.map(val=>{
                        return val.split('|')
                    });
                    this.data = data
                }
                this.data.filter(val=>{
                    let obj = {}
                   val.filter((item,index)=>{
                       obj.name = index == 2
                   })
                   this.data2.push(obj)
                });
                console.log(this.data2);
            })
        },
        methods: {
            longzhuashou() {
                port.postMessage({
                    code: 'save_goods_info',
                    params: {
                        sortfield: 'PBuy',
                        sortdirec: '1',
                        pageSize: '5',
                        pageNum: '1',
                        tkn: 'eastmoney',
                        code: '',
                        mkt: '2',
                        dateNum: '',
                        cfg: 'lhbjgtj',
                        startDateTime: '2021-07-27',
                        endDateTime: '2021-07-27',
                    }
                })
            }
        }
    }
</script>
<style scoped>
    .standalone {
        z-index: 10000000;
        position: fixed;
        right: 0;
        top: 0;
    }
</style>