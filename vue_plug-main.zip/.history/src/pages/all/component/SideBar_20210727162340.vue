<template>
    <div class="standalone">
        <button>龙抓手</button>
    </div>
</template>
<script>
export default {
    data() {
        return {
            
        }
    },
    methods: {
        
    }
}
</script>
<style scoped>
.standalone {
    z-index: 10000000;
    position: fixed;
    right: 0;
    top: 0;
}
</style>
