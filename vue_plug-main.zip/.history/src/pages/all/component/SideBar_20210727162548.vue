<template>
    <div class="standalone">
        <button @click="longzhuashou">龙抓手</button>
    </div>
</template>
<script>
var port = chrome.runtime.connect({
    name: 'LOGIN_DATA',
})
export default {
    data() {
        return {}
    },
    methods: {
        longzhuashou() {
            port.postMessage({
                code: 'save_goods_info',
                data: result
            })
        },
    },
}
</script>
<style scoped>
.standalone {
    z-index: 10000000;
    position: fixed;
    right: 0;
    top: 0;
}
</style>
