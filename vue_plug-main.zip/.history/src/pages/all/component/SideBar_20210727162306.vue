<template>
    <div class="standalone">
        111111111
    </div>
</template>
<script>
export default {
    data() {
        return {
            
        }
    },
    methods: {
        
    }
}
</script>
<style scoped>
.standalone {
    z-index: 10000000;
    position: fixed;
    right: 0;
    top: 0;
    background: #ededed;
    width: 200px;
    height: 100vh;
    text-align: center;
    color: #3a9f73;
}
</style>
