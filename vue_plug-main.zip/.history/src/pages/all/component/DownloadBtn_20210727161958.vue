<template>
    <button @click="setValue">
        这是植入到页面的按钮1
    </button>
</template>
<script>
export default {
    data() {
        return {}
    },
    methods: {
        setValue() {
            this.a = '2'
        }
    }
}
</script>
<style scoped>
button {
    background: #15221c;
}
</style>
