<template>
  <div>新标签页</div>
</template>

<script>
export default {
    name: 'override'
}
</script>

<style scoped>

</style>
